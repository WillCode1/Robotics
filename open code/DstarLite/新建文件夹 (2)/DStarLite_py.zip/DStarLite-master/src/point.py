'''
Created on Nov 5, 2009

@author: ben
'''

class point (object):
    def __init__ (self,x,y):
        self.x = x
        self.y = y