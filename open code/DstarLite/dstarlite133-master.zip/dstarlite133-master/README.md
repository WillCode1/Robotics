# D* Lite -- CS 133b Final Project
## Rahil Bathwal and Vignesh Varadarajan

This implementation of dstarlite is designed to run on various generated mazes. 
The robot's visibility radius in simulation can also be changed in `grid.py`.

    Usage: python3 dstarlite.py [maze_num]
    The maze_num maps as follows.
    Small maze: 0
    Large maze: 1
    No path: 2
